
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const FinTabApp());
}

class FinTabApp extends StatelessWidget {
  const FinTabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FinTab Expense',
      theme: ThemeData(
        colorSchemeSeed: Colors.green,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF6F8F6),
      ),
      home: const HomePage(),
    );
  }
}

class ExpenseTxn {
  final String id;
  final String title;
  final String category;
  final double amount;
  final String dateIso;

  ExpenseTxn({
    required this.id,
    required this.title,
    required this.category,
    required this.amount,
    required this.dateIso,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'category': category,
        'amount': amount,
        'dateIso': dateIso,
      };

  factory ExpenseTxn.fromJson(Map<String, dynamic> m) => ExpenseTxn(
        id: m['id'] ?? '',
        title: m['title'] ?? '',
        category: m['category'] ?? 'Remaining / Misc',
        amount: (m['amount'] ?? 0).toDouble(),
        dateIso: m['dateIso'] ?? DateTime.now().toIso8601String(),
      );
}

class BudgetStore {
  static const _key = 'fintab_v2_state';

  String profile = 'Household';
  String monthKey = '';
  double totalMonthlyBudget = 0;
  Map<String, double> baseAllocation = {};
  Map<String, double> monthAllocation = {};
  Map<String, double> spent = {};
  List<ExpenseTxn> txns = [];

  static String currentMonthKey() {
    final d = DateTime.now();
    return '${d.year}-${d.month.toString().padLeft(2, '0')}';
  }

  static List<String> categoriesFor(String profile) {
    if (profile == 'Shopkeeper') {
      return [
        'Shop Rent',
        'Shop Bills',
        'Staff Expense',
        'Stock / Purchase',
        'Transport',
        'Recharge / Internet',
        'Petrol',
        'EMI',
        'Home Expense',
        'User Hand Cash',
        'Remaining / Misc',
      ];
    }
    if (profile == 'Student') {
      return [
        'Pocket Money',
        'Food',
        'Travel',
        'Recharge / Internet',
        'Study / Books',
        'Hostel / Rent',
        'Fees',
        'Entertainment',
        'Medicine',
        'Remaining / Misc',
      ];
    }
    return [
      'Grocery',
      'Rent',
      'Light Bill / Recharge',
      'Kids School Fees',
      'Milk',
      'Vegetables / Fruits',
      'Medicine / Treatment',
      'Petrol',
      'Kids Pocket Money',
      'Home Hand Cash',
      'User Hand Cash',
      'EMI',
      'Remaining / Misc',
    ];
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw != null) {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      profile = m['profile'] ?? 'Household';
      monthKey = m['monthKey'] ?? '';
      totalMonthlyBudget = (m['totalMonthlyBudget'] ?? 0).toDouble();
      baseAllocation = Map<String, double>.from(
        (m['baseAllocation'] ?? {}).map(
          (k, v) => MapEntry(k, (v ?? 0).toDouble()),
        ),
      );
      monthAllocation = Map<String, double>.from(
        (m['monthAllocation'] ?? {}).map(
          (k, v) => MapEntry(k, (v ?? 0).toDouble()),
        ),
      );
      spent = Map<String, double>.from(
        (m['spent'] ?? {}).map(
          (k, v) => MapEntry(k, (v ?? 0).toDouble()),
        ),
      );
      txns = ((m['txns'] ?? []) as List)
          .map((e) => ExpenseTxn.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }

    _ensureCategories();
    _rolloverIfNeeded();
    await save();
  }

  void _ensureCategories() {
    final cats = categoriesFor(profile);
    for (final c in cats) {
      baseAllocation.putIfAbsent(c, () => 0);
      monthAllocation.putIfAbsent(c, () => baseAllocation[c] ?? 0);
      spent.putIfAbsent(c, () => 0);
    }
  }

  void _rolloverIfNeeded() {
    final nowKey = currentMonthKey();
    if (monthKey.isEmpty) {
      monthKey = nowKey;
      _ensureCategories();
      return;
    }
    if (monthKey == nowKey) return;

    final cats = categoriesFor(profile);
    final newMonthAllocation = <String, double>{};
    for (final c in cats) {
      final oldAllocation = monthAllocation[c] ?? 0;
      final oldSpent = spent[c] ?? 0;
      final carry = (oldAllocation - oldSpent) > 0 ? (oldAllocation - oldSpent) : 0;
      newMonthAllocation[c] = (baseAllocation[c] ?? 0) + carry;
    }
    monthAllocation = newMonthAllocation;
    spent = {for (final c in cats) c: 0};
    monthKey = nowKey;
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
      _key,
      jsonEncode({
        'profile': profile,
        'monthKey': monthKey,
        'totalMonthlyBudget': totalMonthlyBudget,
        'baseAllocation': baseAllocation,
        'monthAllocation': monthAllocation,
        'spent': spent,
        'txns': txns.map((e) => e.toJson()).toList(),
      }),
    );
  }

  double get totalAllocated =>
      monthAllocation.values.fold(0.0, (a, b) => a + b);

  double get totalSpent => spent.values.fold(0.0, (a, b) => a + b);

  double get totalRemaining => totalAllocated - totalSpent;

  void setProfile(String newProfile) {
    if (newProfile == profile) return;
    profile = newProfile;
    baseAllocation = {};
    monthAllocation = {};
    spent = {};
    totalMonthlyBudget = 0;
    txns = [];
    monthKey = currentMonthKey();
    _ensureCategories();
  }

  void configureBudget(double total, Map<String, double> entered) {
    totalMonthlyBudget = total;
    final cats = categoriesFor(profile);
    double sum = 0;

    for (final c in cats) {
      if (c == 'Remaining / Misc') continue;
      final v = entered[c] ?? 0;
      baseAllocation[c] = v;
      sum += v;
    }

    final remaining = total - sum;
    baseAllocation['Remaining / Misc'] = remaining > 0 ? remaining : 0;

    for (final c in cats) {
      final currentSpent = spent[c] ?? 0;
      monthAllocation[c] = baseAllocation[c] ?? 0;
      spent[c] = currentSpent;
    }
  }

  void addExpense({
    required String title,
    required String category,
    required double amount,
  }) {
    spent[category] = (spent[category] ?? 0) + amount;
    txns.insert(
      0,
      ExpenseTxn(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        title: title,
        category: category,
        amount: amount,
        dateIso: DateTime.now().toIso8601String(),
      ),
    );
  }

  void deleteTxn(ExpenseTxn txn) {
    txns.removeWhere((e) => e.id == txn.id);
    spent[txn.category] = ((spent[txn.category] ?? 0) - txn.amount);
    if ((spent[txn.category] ?? 0) < 0) spent[txn.category] = 0;
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final store = BudgetStore();
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await store.load();
    if (mounted) setState(() => loading = false);
  }

  String money(double v) => '₹${v.toStringAsFixed(0)}';

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final cats = BudgetStore.categoriesFor(store.profile);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'FinTab Expense',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Profile',
            initialValue: store.profile,
            onSelected: (v) async {
              final ok = await _confirmProfileChange(v);
              if (ok != true) return;
              setState(() => store.setProfile(v));
              await store.save();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'Household', child: Text('Household')),
              PopupMenuItem(value: 'Shopkeeper', child: Text('Shopkeeper')),
              PopupMenuItem(value: 'Student', child: Text('Student')),
            ],
            icon: const Icon(Icons.account_circle_outlined),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddExpense,
        icon: const Icon(Icons.add),
        label: const Text('Add Expense'),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
          children: [
            _profileStrip(),
            const SizedBox(height: 12),
            _summaryCard(),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _miniCard(
                    'Spent',
                    money(store.totalSpent),
                    Icons.trending_down,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _miniCard(
                    'Remaining',
                    money(store.totalRemaining),
                    Icons.savings_outlined,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Budget Allocation',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
                  ),
                ),
                TextButton.icon(
                  onPressed: _showBudgetSetup,
                  icon: const Icon(Icons.tune),
                  label: const Text('Set Budget'),
                ),
              ],
            ),
            if (store.totalAllocated <= 0)
              _emptyBudgetCard()
            else
              ...cats.map(_categoryCard),
            const SizedBox(height: 16),
            const Text(
              'Recent Expenses',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            if (store.txns.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(18),
                  child: Text('No expenses yet. Tap “Add Expense” to add one.'),
                ),
              )
            else
              ...store.txns.take(12).map(_txnTile),
          ],
        ),
      ),
    );
  }

  Widget _profileStrip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.green.withOpacity(.08),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          const Icon(Icons.person_outline),
          const SizedBox(width: 8),
          Text(
            '${store.profile} • ${store.monthKey}',
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          const Spacer(),
          const Text('Offline'),
          const SizedBox(width: 4),
          const Icon(Icons.lock_outline, size: 17),
        ],
      ),
    );
  }

  Widget _summaryCard() {
    final progress = store.totalAllocated <= 0
        ? 0.0
        : (store.totalSpent / store.totalAllocated).clamp(0.0, 1.0);

    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Total Available Budget'),
            const SizedBox(height: 5),
            Text(
              money(store.totalAllocated),
              style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Text(
              'Monthly base: ${money(store.totalMonthlyBudget)}  •  Includes rollover',
              style: TextStyle(color: Colors.grey.shade700),
            ),
            const SizedBox(height: 16),
            LinearProgressIndicator(
              value: progress,
              minHeight: 9,
              borderRadius: BorderRadius.circular(20),
            ),
            const SizedBox(height: 8),
            Text(
              '${money(store.totalSpent)} spent • ${money(store.totalRemaining)} left',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }

  Widget _miniCard(String title, String value, IconData icon) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon),
            const SizedBox(height: 8),
            Text(title),
            Text(
              value,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }

  Widget _emptyBudgetCard() {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            const Icon(Icons.account_balance_wallet_outlined, size: 42),
            const SizedBox(height: 8),
            const Text(
              'Start by setting your monthly budget and category allocation.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            FilledButton(
              onPressed: _showBudgetSetup,
              child: const Text('Set Monthly Budget'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _categoryCard(String cat) {
    final allocated = store.monthAllocation[cat] ?? 0;
    final used = store.spent[cat] ?? 0;
    final left = allocated - used;
    final progress =
        allocated <= 0 ? 0.0 : (used / allocated).clamp(0.0, 1.0);

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _showAddExpense(preselectedCategory: cat),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      cat,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                  Text(
                    '${money(left)} left',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: left < 0 ? Colors.red : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              LinearProgressIndicator(
                value: progress,
                minHeight: 7,
                borderRadius: BorderRadius.circular(20),
              ),
              const SizedBox(height: 7),
              Row(
                children: [
                  Text('Budget ${money(allocated)}'),
                  const Spacer(),
                  Text('Spent ${money(used)}'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _txnTile(ExpenseTxn txn) {
    final d = DateTime.tryParse(txn.dateIso) ?? DateTime.now();
    final date = '${d.day}/${d.month}/${d.year}';
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 7),
      child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.arrow_upward)),
        title: Text(txn.title),
        subtitle: Text('${txn.category} • $date'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '-${money(txn.amount)}',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            IconButton(
              tooltip: 'Delete',
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                setState(() => store.deleteTxn(txn));
                await store.save();
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<bool?> _confirmProfileChange(String newProfile) {
    if (newProfile == store.profile) return Future.value(false);
    return showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Switch to $newProfile?'),
        content: const Text(
          'Changing profile resets the current local budget setup and expense history for this prototype.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Switch'),
          ),
        ],
      ),
    );
  }

  Future<void> _showBudgetSetup() async {
    final cats = BudgetStore.categoriesFor(store.profile);
    final totalCtrl = TextEditingController(
      text: store.totalMonthlyBudget > 0
          ? store.totalMonthlyBudget.toStringAsFixed(0)
          : '',
    );
    final ctrls = <String, TextEditingController>{
      for (final c in cats)
        if (c != 'Remaining / Misc')
          c: TextEditingController(
            text: (store.baseAllocation[c] ?? 0) > 0
                ? (store.baseAllocation[c] ?? 0).toStringAsFixed(0)
                : '',
          ),
    };

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheet) {
            double sumEntered() => ctrls.values.fold(
                  0.0,
                  (sum, c) => sum + (double.tryParse(c.text) ?? 0),
                );
            double total() => double.tryParse(totalCtrl.text) ?? 0;

            return Padding(
              padding: EdgeInsets.fromLTRB(
                16,
                16,
                16,
                MediaQuery.of(ctx).viewInsets.bottom + 18,
              ),
              child: ListView(
                shrinkWrap: true,
                children: [
                  Text(
                    'Set ${store.profile} Monthly Budget',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Set the total budget first, then allocate amounts. Unallocated money automatically goes to Remaining / Misc.',
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: totalCtrl,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Total Monthly Budget',
                      prefixText: '₹ ',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (_) => setSheet(() {}),
                  ),
                  const SizedBox(height: 14),
                  ...ctrls.entries.map(
                    (e) => Padding(
                      padding: const EdgeInsets.only(bottom: 9),
                      child: TextField(
                        controller: e.value,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: InputDecoration(
                          labelText: e.key,
                          prefixText: '₹ ',
                          border: const OutlineInputBorder(),
                        ),
                        onChanged: (_) => setSheet(() {}),
                      ),
                    ),
                  ),
                  Builder(
                    builder: (_) {
                      final left = total() - sumEntered();
                      return Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: left < 0
                              ? Colors.red.withOpacity(.08)
                              : Colors.green.withOpacity(.08),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          left < 0
                              ? 'Allocation exceeds total budget by ${money(left.abs())}'
                              : 'Remaining / Misc will get ${money(left)}',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: left < 0 ? Colors.red : null,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: () async {
                      final t = total();
                      final entered = {
                        for (final e in ctrls.entries)
                          e.key: double.tryParse(e.value.text) ?? 0,
                      };
                      final sum = entered.values.fold(0.0, (a, b) => a + b);
                      if (t <= 0) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Please enter total monthly budget.'),
                          ),
                        );
                        return;
                      }
                      if (sum > t) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content:
                                Text('Category allocation cannot exceed total.'),
                          ),
                        );
                        return;
                      }
                      setState(() => store.configureBudget(t, entered));
                      await store.save();
                      if (ctx.mounted) Navigator.pop(ctx);
                    },
                    icon: const Icon(Icons.save_outlined),
                    label: const Text('Save Budget'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _showAddExpense({String? preselectedCategory}) async {
    final cats = BudgetStore.categoriesFor(store.profile);
    final titleCtrl = TextEditingController();
    final amountCtrl = TextEditingController();
    String selected = preselectedCategory ??
        cats.firstWhere(
          (e) => (store.monthAllocation[e] ?? 0) > 0,
          orElse: () => cats.first,
        );

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheet) {
            final left = (store.monthAllocation[selected] ?? 0) -
                (store.spent[selected] ?? 0);

            return Padding(
              padding: EdgeInsets.fromLTRB(
                16,
                16,
                16,
                MediaQuery.of(ctx).viewInsets.bottom + 18,
              ),
              child: ListView(
                shrinkWrap: true,
                children: [
                  const Text(
                    'Add Expense',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<String>(
                    value: selected,
                    items: cats
                        .map(
                          (e) => DropdownMenuItem(
                            value: e,
                            child: Text(e),
                          ),
                        )
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setSheet(() => selected = v);
                    },
                    decoration: const InputDecoration(
                      labelText: 'Category',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(11),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(.07),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${money(left)} available in $selected',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: titleCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Expense title',
                      hintText: 'e.g. Grocery shopping',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: amountCtrl,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Amount',
                      prefixText: '₹ ',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: () async {
                      final amt = double.tryParse(amountCtrl.text) ?? 0;
                      if (amt <= 0) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Enter a valid expense amount.'),
                          ),
                        );
                        return;
                      }
                      setState(() {
                        store.addExpense(
                          title: titleCtrl.text.trim().isEmpty
                              ? selected
                              : titleCtrl.text.trim(),
                          category: selected,
                          amount: amt,
                        );
                      });
                      await store.save();
                      if (ctx.mounted) Navigator.pop(ctx);
                    },
                    icon: const Icon(Icons.add),
                    label: const Text('Save Expense'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
